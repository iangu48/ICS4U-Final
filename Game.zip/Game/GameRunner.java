/*
	File Name:	 GameRunner.java
	Name:			 Shawn Wang
	Class:		 ICS4U1
	Date:			 June 15, 2017
	Description: Starts the game file and allows the user to play "The dark room."
*/

package Game;

import Game.GameFiles.Game;

public class GameRunner {

   public static void main(String[] args) {
   
      new Game(); //Generates an instance of the game
       
   }//main method

}//GameRunner class