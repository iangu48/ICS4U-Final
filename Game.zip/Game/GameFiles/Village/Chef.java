/*
	ICS4U
	Ian Gu
	6/2/2017
	AY Jackson SS
	
	This class is a subclass of worker
 */
 
package Game.GameFiles.Village;

import Game.GameFiles.GameMechanics.GameMechanics;
import Game.GameFiles.Room.*;

public class Chef extends Workers {

   //constants
   public static final Material PLUSCOOKEDMEAT = new Material(GameMechanics.COOKEDMEATID, GameMechanics.CHEFCOOKEDMEAT);
   public static final Material MINUSWOOD = new Material(GameMechanics.WOODID, GameMechanics.CHEFWOOD);
   public static final Material MINUSMEAT = new Material(GameMechanics.MEATID, GameMechanics.CHEFMEAT);

   //Returns final resources of each type
   public Resource gatherResources() {
      int workers = getNumWorkers();
      Item[] items = {new Material(MINUSWOOD, MINUSWOOD.getAmount() * workers), new Material(MINUSMEAT, MINUSMEAT.getAmount() * workers), new Material(PLUSCOOKEDMEAT, PLUSCOOKEDMEAT.getAmount() * workers)};
      return new Resource(items);
   }

   public String toString() {
      return "Chef";
   }
   
   //Returns types of resources that gatherResources gives
   public Resource getUnitResource()
   {
      Item[] items = {new Material(PLUSCOOKEDMEAT), new Material(MINUSWOOD), new Material(MINUSMEAT)};
      return new Resource(items);
   }
}